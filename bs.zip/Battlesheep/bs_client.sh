#!/bin/sh
~/battlesheep client