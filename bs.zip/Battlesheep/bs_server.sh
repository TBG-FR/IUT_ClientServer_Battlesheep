#!/bin/sh
~/battlesheep server