#include "UserStorage.h"



UserStorage::UserStorage()
{
}


UserStorage::~UserStorage()
{
}
