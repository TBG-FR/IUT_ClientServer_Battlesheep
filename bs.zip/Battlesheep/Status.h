#ifndef BATTLESHIP_STATUS

/* TODO : Improve that ENUM */

enum Status {

  NONE,
  ONE_PLAYER,
  GAME_CREATED,
  GAME_CONFIGURED,
  TWO_PLAYERS,
  INGAME,
  ENDGAME,
  GAME_PAUSED,
  
};

#endif
